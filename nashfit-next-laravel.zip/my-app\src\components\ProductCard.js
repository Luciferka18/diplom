"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { BadgeCheck, Heart, PackageCheck, Star } from "lucide-react";
import AddToCartButton from "@/components/AddToCartButton";
import { apiPost } from "@/services/api";
import { useAuth } from "@/context/AuthContext";

const money = (value) => new Intl.NumberFormat("ru-RU", { style: "currency", currency: "RUB", maximumFractionDigits: 0 }).format(Number(value || 0));

export default function ProductCard({ product, compact = false }) {
  const { isAuthed } = useAuth();
  const [favorite, setFavorite] = useState(Boolean(product.is_favorite));
  const variants = Array.isArray(product.variants) ? product.variants.filter((item) => item.is_active !== false) : [];
  const defaultVariant = useMemo(() => variants.find((item) => Number(item.stock) > 0) || variants[0] || null, [variants]);
  const currentPrice = defaultVariant?.price ?? product.price;
  const oldPrice = defaultVariant?.old_price ?? product.old_price;
  const image = defaultVariant?.image_url || product.image_url || product.gallery?.[0];

  async function toggleFavorite(event) {
    event.preventDefault();
    event.stopPropagation();
    if (!isAuthed) {
      window.location.href = `/login?next=/shop/${product.id}`;
      return;
    }
    const response = await apiPost(`/products/${product.id}/favorite`, {});
    setFavorite(Boolean(response?.is_favorite));
  }

  return (
    <article className="group relative flex h-full flex-col overflow-hidden rounded-[24px] border border-[color:var(--stroke)] bg-[color:var(--panel)] shadow-[var(--shadow-sm)] transition duration-200 hover:-translate-y-1 hover:border-[color:var(--stroke-strong)] hover:shadow-[var(--shadow-md)]">
      <Link href={`/shop/${product.id}`} className={`relative block overflow-hidden bg-[color:var(--panel-2)] ${compact ? "aspect-[5/4]" : "aspect-square"}`}>
        {image ? (
          <img src={image} alt={product.name} className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]" />
        ) : (
          <div className="grid h-full w-full place-items-center bg-[linear-gradient(145deg,var(--accent-soft),var(--secondary-soft))] text-sm font-bold text-[color:var(--muted)]">НашФит</div>
        )}
        <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-black/45 to-transparent" />
        <div className="absolute left-3 top-3 flex flex-wrap gap-2">
          {product.trainer_pick ? <span className="inline-flex items-center gap-1 rounded-full bg-[color:var(--secondary)] px-2.5 py-1 text-[11px] font-black text-white"><BadgeCheck className="h-3.5 w-3.5" /> Выбор тренера</span> : null}
          {product.is_new ? <span className="rounded-full bg-[color:var(--warm)] px-2.5 py-1 text-[11px] font-black text-white">Новинка</span> : null}
          {!product.in_stock ? <span className="rounded-full bg-black/65 px-2.5 py-1 text-[11px] font-bold text-white backdrop-blur">Нет в наличии</span> : null}
        </div>
      </Link>

      <button
        onClick={toggleFavorite}
        aria-label="Добавить в избранное"
        className={`absolute right-3 top-3 z-10 grid h-10 w-10 place-items-center rounded-full border backdrop-blur transition ${favorite ? "border-[color:var(--danger)] bg-[color:var(--danger)] text-white" : "border-white/30 bg-black/35 text-white hover:bg-black/55"}`}
      >
        <Heart className={`h-5 w-5 ${favorite ? "fill-current" : ""}`} />
      </button>

      <div className="flex flex-1 flex-col p-5">
        <div className="text-[11px] font-black uppercase tracking-[0.14em] text-[color:var(--warm)]">{product.brand || product.category || "НашФит"}</div>
        <Link href={`/shop/${product.id}`} className="mt-2 text-lg font-black leading-snug tracking-[-0.025em] text-[color:var(--text)] transition group-hover:text-[color:var(--accent)]">{product.name}</Link>
        <p className="mt-2 line-clamp-2 text-sm leading-6 text-[color:var(--muted)]">{product.short_description || product.description}</p>

        <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[color:var(--muted)]">
          <span className="inline-flex items-center gap-1"><Star className="h-4 w-4 fill-[color:var(--warning)] text-[color:var(--warning)]" /> {Number(product.rating || 0).toFixed(1)}</span>
          <span>{product.reviews_count || 0} отзывов</span>
          <span className="ml-auto inline-flex items-center gap-1"><PackageCheck className="h-4 w-4" /> {product.stock || 0} шт.</span>
        </div>

        {variants.length > 1 ? <div className="mt-3 text-xs text-[color:var(--muted)]">{variants.length} варианта · от {money(Math.min(...variants.map((item) => Number(item.price || product.price))))}</div> : null}

        <div className="mt-auto flex flex-col gap-4 pt-5 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <div className="text-xl font-black tracking-[-0.035em] text-[color:var(--text)]">{money(currentPrice)}</div>
            {oldPrice ? <div className="text-xs text-[color:var(--muted)] line-through">{money(oldPrice)}</div> : null}
          </div>
          <AddToCartButton product={product} variant={defaultVariant} className="w-full sm:w-auto" />
        </div>
      </div>
    </article>
  );
}
