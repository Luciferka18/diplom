<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ArticleResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $author = $this->resource->relationLoaded('author') ? $this->author : null;
        $trainer = $author && $author->relationLoaded('trainerProfile') ? $author->trainerProfile : null;
        $viewer = $request->user('sanctum') ?? $request->user();

        return [
            'id' => $this->id,
            'title' => $this->title,
            'slug' => $this->slug,
            'excerpt' => $this->excerpt,
            'cover_image_url' => $this->cover_image_url,
            'category' => $this->category,
            'content' => $this->content,
            'status' => $this->status,
            'is_featured' => (bool) $this->is_featured,
            'is_trainer_article' => (bool) $this->is_trainer_article,
            'reading_time_minutes' => (int) $this->reading_time_minutes,
            'views_count' => (int) $this->views_count,
            'helpful_count' => (int) $this->helpful_count,
            'rejection_reason' => $this->rejection_reason,
            'published_at' => $this->published_at,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'author' => $author ? [
                'id' => $author->id,
                'name' => $author->name,
                'role' => $author->role,
                'is_trainer' => $author->role === 'trainer',
                'trainer' => $trainer ? [
                    'id' => $trainer->id,
                    'specialization' => $trainer->specialization,
                    'experience_years' => $trainer->experience_years,
                    'photo_url' => $trainer->photo_url,
                ] : null,
            ] : null,
            'is_favorited' => $viewer
                ? $this->favoritedBy()->where('users.id', $viewer->id)->exists()
                : false,
            'is_helpful' => $viewer
                ? $this->helpfulVoters()->where('users.id', $viewer->id)->exists()
                : false,
        ];
    }
}
